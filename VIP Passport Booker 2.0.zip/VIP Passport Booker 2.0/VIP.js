var START_MONEY = 10000;
var LOW_WALLET = 2000;
var POINTS_PER_FLIGHT = 10;
var BAG_PRICE = 25;
var PROMO_CODE = "VIP10";
var PROMO_EXTRA = 10;

var DEFAULT_USER = {
  email: "reynchm@gmail.com",
  password: "1234567",
  name: "Admin",
  isAdmin: true
};

function getUsers() {
  var list = JSON.parse(localStorage.getItem("vip_users") || "[]");
  var hasDefault = list.some(function (u) {
    return u.email.toLowerCase() === DEFAULT_USER.email.toLowerCase();
  });
  if (!hasDefault) {
    list.unshift(DEFAULT_USER);
    localStorage.setItem("vip_users", JSON.stringify(list));
  }
  return list;
}
function saveUsers(list) { localStorage.setItem("vip_users", JSON.stringify(list)); }

function findUser(email, password) {
  return getUsers().find(function (u) {
    return u.email.toLowerCase() === email.toLowerCase() && u.password === password;
  });
}

function setSession(user) {
  localStorage.setItem("vip_session", JSON.stringify({
    email: user.email,
    name: user.name || user.email,
    isAdmin: !!user.isAdmin || user.email.toLowerCase() === DEFAULT_USER.email.toLowerCase()
  }));
}
function getSession() { return JSON.parse(localStorage.getItem("vip_session") || "null"); }
function clearSession() { localStorage.removeItem("vip_session"); }
function isAdmin() { var s = getSession(); return s && s.isAdmin; }

function slug(email) { return String(email || "").toLowerCase().replace(/[^a-z0-9]/g, "_"); }
function userKey(base, email) {
  var s = getSession();
  var e = email || (s ? s.email : "guest");
  return base + "_" + slug(e);
}

function getBalance(email) {
  var key = userKey("vip_wallet", email);
  var saved = localStorage.getItem(key);
  if (saved === null) { localStorage.setItem(key, String(START_MONEY)); return START_MONEY; }
  return Number(saved);
}
function setBalance(amount, email) {
  localStorage.setItem(userKey("vip_wallet", email), String(amount));
  updateDisplays();
}
function getTotalFlights(email) {
  return Number(localStorage.getItem(userKey("vip_total_flights", email)) || "0");
}
function addFlightCount() {
  var n = getTotalFlights() + 1;
  localStorage.setItem(userKey("vip_total_flights"), String(n));
  return n;
}
function getPoints(email) {
  return Number(localStorage.getItem(userKey("vip_points", email)) || "0");
}
function addPoints(n) {
  localStorage.setItem(userKey("vip_points"), String(getPoints() + n));
}
function getBookings(email) {
  return JSON.parse(localStorage.getItem(userKey("vip_bookings", email)) || "[]");
}
function saveBookings(list, email) {
  localStorage.setItem(userKey("vip_bookings", email), JSON.stringify(list));
}

function isFrozen(email) {
  var e = email || (getSession() && getSession().email);
  if (!e) return false;
  var u = getUsers().find(function (x) { return x.email.toLowerCase() === e.toLowerCase(); });
  return u && u.frozen;
}

function getMembership(total) {
  if (total >= 50) return { name: "Platinum", discount: 2.5 };
  if (total >= 40) return { name: "Diamond", discount: 2.0 };
  if (total >= 30) return { name: "Gold", discount: 1.5 };
  if (total >= 20) return { name: "Silver", discount: 1.0 };
  if (total >= 10) return { name: "Bronze", discount: 0.5 };
  return { name: "Member", discount: 0 };
}
function formatMoney(n) { return Number(n).toLocaleString("en-US"); }

function logActivity(text) {
  var log = JSON.parse(localStorage.getItem("vip_activity") || "[]");
  log.unshift({ t: new Date().toLocaleString(), text: text });
  if (log.length > 80) log = log.slice(0, 80);
  localStorage.setItem("vip_activity", JSON.stringify(log));
}

function playTone(freq, ms) {
  try {
    var ctx = new (window.AudioContext || window.webkitAudioContext)();
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = freq;
    o.connect(g); g.connect(ctx.destination);
    g.gain.setValueAtTime(0.08, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + ms / 1000);
    o.start(); o.stop(ctx.currentTime + ms / 1000);
  } catch (e) {}
}
function clickSound() { playTone(520, 80); }
function successSound() { playTone(660, 120); setTimeout(function () { playTone(880, 160); }, 130); }

function randomFlightNo() {
  return "VP" + String(100 + Math.floor(Math.random() * 800));
}
function randomGate() {
  var letters = "ABCDE";
  return letters[Math.floor(Math.random() * letters.length)] + (1 + Math.floor(Math.random() * 12));
}
function randomStatus() {
  return Math.random() < 0.8 ? "On Time" : "Delayed";
}

function updateDisplays() {
  var session = getSession();
  var bal = getBalance();
  var total = getTotalFlights();
  var pts = getPoints();
  var mem = getMembership(total);

  var setTxt = function (id, val) {
    var el = document.getElementById(id);
    if (el) el.textContent = val;
  };
  setTxt("balance", formatMoney(bal));
  setTxt("home-balance", "$" + formatMoney(bal));
  setTxt("topup-balance", "$" + formatMoney(bal));
  setTxt("count", total);
  setTxt("home-points", pts);
  setTxt("header-points", pts);
  if (session) setTxt("welcome-name", session.name);

  var badge = document.getElementById("member-badge");
  if (badge) { badge.textContent = mem.name; badge.className = "member-badge " + mem.name; }
  var card = document.getElementById("membership-card");
  if (card) card.className = "membership-card " + mem.name;
  setTxt("card-class-name", mem.name);
  setTxt("card-discount", mem.discount + "% OFF");
  if (session) setTxt("card-user-name", session.name + " · " + session.email);

  setTxt("prof-name", session ? session.name : "—");
  setTxt("prof-email", session ? session.email : "—");
  setTxt("prof-class", mem.name + " (" + mem.discount + "% off)");
  setTxt("prof-wallet", "$" + formatMoney(bal));
  setTxt("prof-points", pts);
  setTxt("prof-flights", total);

  var warn = document.getElementById("low-wallet");
  if (warn) warn.hidden = !(bal < LOW_WALLET);

  var navAdmin = document.getElementById("nav-admin");
  if (navAdmin) navAdmin.hidden = !isAdmin();
}

var SEAT_LAYOUTS = {
  VIP: { rows: ["1", "2"], seats: ["A", "B", "C", "D"], aisleAfter: 1 },
  Business: { rows: ["1", "2", "3"], seats: ["A", "B", "C", "D"], aisleAfter: 1 },
  Economy: { rows: ["1", "2", "3", "4", "5"], seats: ["A", "B", "C", "D", "E", "F"], aisleAfter: 2 }
};

function getTakenSeats() {
  var taken = {};
  getUsers().forEach(function (u) {
    getBookings(u.email).forEach(function (b) {
      if (b.seat && b.flightClass) taken[b.flightClass + "|" + b.seat] = true;
    });
  });
  return taken;
}

function buildSeatMap(flightClass) {
  var map = document.getElementById("seat-map");
  var layout = SEAT_LAYOUTS[flightClass];
  if (!layout) {
    map.innerHTML = '<p class="seat-hint">Select a flight class first</p>';
    document.getElementById("selected-seat").value = "";
    document.getElementById("seat-label").textContent = "No seat selected";
    return;
  }
  var taken = getTakenSeats();
  var html = "";
  layout.rows.forEach(function (row) {
    html += '<div class="seat-row">';
    layout.seats.forEach(function (letter, idx) {
      if (idx === layout.aisleAfter + 1) html += '<span class="aisle"></span>';
      var seatId = row + letter;
      var isTaken = taken[flightClass + "|" + seatId];
      html += '<button type="button" class="seat' + (isTaken ? " taken" : "") + '" data-seat="' + seatId + '"' +
        (isTaken ? " disabled" : "") + ">" + seatId + "</button>";
    });
    html += "</div>";
  });
  map.innerHTML = html;
  map.querySelectorAll(".seat:not(.taken)").forEach(function (btn) {
    btn.onclick = function () {
      clickSound();
      map.querySelectorAll(".seat").forEach(function (s) { s.classList.remove("selected"); });
      btn.classList.add("selected");
      document.getElementById("selected-seat").value = btn.dataset.seat;
      document.getElementById("seat-label").textContent = "Seat: " + btn.dataset.seat;
    };
  });
  document.getElementById("selected-seat").value = "";
  document.getElementById("seat-label").textContent = "No seat selected";
}

function calcPrice() {
  var officeSelect = document.getElementById("office");
  var classSelect = document.getElementById("flight-class");
  var preview = document.getElementById("price-preview");
  var officeOpt = officeSelect.options[officeSelect.selectedIndex];
  var classOpt = classSelect.options[classSelect.selectedIndex];
  if (!officeOpt || !officeOpt.dataset.price || !classOpt || !classOpt.dataset.mult) {
    preview.textContent = "Select options to see price";
    return null;
  }
  var base = Number(officeOpt.dataset.price);
  var mult = Number(classOpt.dataset.mult);
  var subtotal = base * mult;
  var mem = getMembership(getTotalFlights());
  var discountAmount = subtotal * (mem.discount / 100);
  var afterMem = subtotal - discountAmount;

  var promo = (document.getElementById("promo").value || "").trim().toUpperCase();
  var promoOff = 0;
  if (promo === PROMO_CODE) promoOff = afterMem * (PROMO_EXTRA / 100);

  var bags = Number(document.getElementById("bags").value || 0);
  var extra = Number(document.getElementById("seat-extra").value || 0);
  var bagCost = bags * BAG_PRICE;
  var oneWay = afterMem - promoOff + bagCost + extra;
  var round = document.getElementById("round-trip").checked;
  var finalPrice = Math.round(round ? oneWay * 1.8 : oneWay);

  preview.innerHTML =
    "Base $" + formatMoney(base) + " × " + classOpt.value + " = $" + formatMoney(subtotal) +
    (mem.discount ? "<br>Member " + mem.name + " −$" + formatMoney(Math.round(discountAmount)) : "") +
    (promoOff ? "<br>Promo VIP10 −$" + formatMoney(Math.round(promoOff)) : "") +
    (bagCost ? "<br>Bags ×" + bags + " +$" + bagCost : "") +
    (extra ? "<br>Seat extra +$" + extra : "") +
    (round ? "<br>Round trip ×1.8" : "") +
    "<br><strong>Total: $" + formatMoney(finalPrice) + "</strong>";
  return finalPrice;
}

["office", "flight-class", "bags", "seat-extra", "promo", "round-trip"].forEach(function (id) {
  var el = document.getElementById(id);
  if (!el) return;
  el.onchange = function () {
    if (id === "flight-class") buildSeatMap(this.value);
    if (id === "round-trip") document.getElementById("return-wrap").hidden = !this.checked;
    calcPrice();
  };
  if (el.tagName === "INPUT" && el.type === "text") el.oninput = calcPrice;
});

document.getElementById("tab-login").onclick = function () {
  document.getElementById("login-form").hidden = false;
  document.getElementById("register-form").hidden = true;
  document.getElementById("tab-login").classList.add("active");
  document.getElementById("tab-register").classList.remove("active");
  document.getElementById("error").textContent = "";
};
document.getElementById("tab-register").onclick = function () {
  document.getElementById("login-form").hidden = true;
  document.getElementById("register-form").hidden = false;
  document.getElementById("tab-register").classList.add("active");
  document.getElementById("tab-login").classList.remove("active");
  document.getElementById("error").textContent = "";
};

document.getElementById("register-form").onsubmit = function (e) {
  e.preventDefault();
  var name = document.getElementById("reg-name").value.trim();
  var email = document.getElementById("reg-email").value.trim();
  var pass = document.getElementById("reg-password").value;
  var pass2 = document.getElementById("reg-password2").value;
  var error = document.getElementById("error");
  var box = document.querySelector(".login-box");
  if (email.toLowerCase() === DEFAULT_USER.email.toLowerCase()) {
    error.textContent = "That email is reserved for Admin."; return;
  }
  if (pass.length < 6) { error.textContent = "Password must be at least 6 characters."; return; }
  if (pass !== pass2) {
    error.textContent = "Passwords do not match.";
    box.classList.remove("shake"); void box.offsetWidth; box.classList.add("shake");
    return;
  }
  var users = getUsers();
  if (users.some(function (u) { return u.email.toLowerCase() === email.toLowerCase(); })) {
    error.textContent = "That username/email is already taken.";
    box.classList.remove("shake"); void box.offsetWidth; box.classList.add("shake");
    return;
  }
  users.push({ email: email, password: pass, name: name, isAdmin: false, frozen: false });
  saveUsers(users);
  setSession({ email: email, name: name, isAdmin: false });
  localStorage.setItem(userKey("vip_wallet"), String(START_MONEY));
  localStorage.setItem(userKey("vip_total_flights"), "0");
  localStorage.setItem(userKey("vip_bookings"), "[]");
  localStorage.setItem(userKey("vip_points"), "0");
  logActivity(name + " created an account");
  error.style.color = "";
  error.textContent = "Account created! Entering…";
  setTimeout(enterApp, 500);
};

document.getElementById("login-form").onsubmit = function (e) {
  e.preventDefault();
  var email = document.getElementById("email").value.trim();
  var password = document.getElementById("password").value;
  var error = document.getElementById("error");
  var box = document.querySelector(".login-box");
  var user = findUser(email, password);
  if (!user) {
    error.textContent = "Incorrect email or password. Create an account if you are new.";
    box.classList.remove("shake"); void box.offsetWidth; box.classList.add("shake");
    return;
  }
  setSession(user);
  logActivity((user.name || user.email) + " logged in");
  error.textContent = "";
  enterApp();
};

function enterApp() {
  document.getElementById("login-page").style.display = "none";
  document.getElementById("app").hidden = false;
  showPage("home");
  updateDisplays();
}

document.getElementById("logout").onclick = function () {
  var s = getSession();
  if (s) logActivity(s.name + " logged out");
  clearSession();
  window.location.href = "";
};

document.getElementById("restart-btn").onclick = function () {
  if (!getSession()) return;
  if (!confirm("Reset YOUR wallet, flights, points, and bookings?")) return;
  localStorage.setItem(userKey("vip_wallet"), String(START_MONEY));
  localStorage.setItem(userKey("vip_total_flights"), "0");
  localStorage.setItem(userKey("vip_bookings"), "[]");
  localStorage.setItem(userKey("vip_points"), "0");
  logActivity(getSession().name + " restarted their account");
  updateDisplays();
  showPage("home");
  alert("Your account data was reset to $10,000.");
};

function showPage(name) {
  document.querySelectorAll(".page").forEach(function (p) { p.hidden = true; });
  document.getElementById("page-" + name).hidden = false;
  document.querySelectorAll(".nav-btn").forEach(function (btn) {
    btn.classList.toggle("active", btn.dataset.page === name);
  });
  if (name === "list") showBookings();
  if (name === "home" || name === "profile" || name === "topup") updateDisplays();
  if (name === "book") { calcPrice(); buildSeatMap(document.getElementById("flight-class").value); }
  if (name === "admin") {
    if (!isAdmin()) { showPage("home"); return; }
    showAdminPanel();
  }
}
document.querySelectorAll(".nav-btn").forEach(function (btn) {
  btn.onclick = function () { if (btn.dataset.page) showPage(btn.dataset.page); };
});

var tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
document.getElementById("date").min = tomorrow.toISOString().slice(0, 10);
document.getElementById("return-date").min = tomorrow.toISOString().slice(0, 10);

document.getElementById("book-form").onsubmit = function (e) {
  e.preventDefault();
  if (isFrozen()) {
    document.getElementById("success").textContent = "Your account is frozen. Contact Admin.";
    document.getElementById("success").style.color = "#e74c3c";
    return;
  }
  var finalPrice = calcPrice();
  if (finalPrice === null) {
    document.getElementById("success").textContent = "Please select class and destination.";
    document.getElementById("success").style.color = "#e74c3c";
    return;
  }
  var seat = document.getElementById("selected-seat").value;
  if (!seat) {
    document.getElementById("success").textContent = "Please choose a seat.";
    document.getElementById("success").style.color = "#e74c3c";
    return;
  }
  if (getBalance() < finalPrice) {
    document.getElementById("success").textContent = "Not enough money. Need $" + formatMoney(finalPrice);
    document.getElementById("success").style.color = "#e74c3c";
    return;
  }

  var loader = document.getElementById("loader");
  loader.hidden = false;

  setTimeout(function () {
    setBalance(getBalance() - finalPrice);
    addFlightCount();
    addPoints(POINTS_PER_FLIGHT);

    var session = getSession();
    var booking = {
      id: Date.now(),
      ticketCode: "VIP-" + Date.now().toString(36).toUpperCase(),
      userEmail: session.email,
      userName: session.name,
      passenger: document.getElementById("pass-name").value.trim(),
      age: document.getElementById("pass-age").value,
      idNumber: document.getElementById("pass-id").value.trim(),
      flightClass: document.getElementById("flight-class").value,
      office: document.getElementById("office").value,
      date: document.getElementById("date").value,
      time: document.getElementById("time").value,
      roundTrip: document.getElementById("round-trip").checked,
      returnDate: document.getElementById("return-date").value || "",
      bags: Number(document.getElementById("bags").value || 0),
      seatExtra: document.getElementById("seat-extra").options[document.getElementById("seat-extra").selectedIndex].text,
      seat: seat,
      price: finalPrice,
      flightNo: randomFlightNo(),
      gate: randomGate(),
      status: randomStatus()
    };
    var list = getBookings();
    list.push(booking);
    saveBookings(list);
    logActivity(session.name + " booked " + booking.office + " (" + booking.flightClass + ", $" + booking.price + ")");

    document.getElementById("book-form").reset();
    document.getElementById("return-wrap").hidden = true;
    document.getElementById("price-preview").textContent = "Select options to see price";
    buildSeatMap("");
    document.getElementById("success").style.color = "";
    document.getElementById("success").textContent = "Booked! +" + POINTS_PER_FLIGHT + " pts · $" + formatMoney(finalPrice);
    updateDisplays();
    loader.hidden = true;
    successSound();
    showTicket(booking);
    setTimeout(function () { document.getElementById("success").textContent = ""; }, 4000);
  }, 900);
};

function qrUrl(text) {
  return "https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=" + encodeURIComponent(text);
}

function showTicket(b) {
  var data = "TICKET:" + b.ticketCode + "|FLT:" + b.flightNo + "|SEAT:" + b.seat + "|TO:" + b.office;
  document.getElementById("ticket-content").innerHTML =
    '<div class="ticket-title">◆ BOARDING PASS</div>' +
    '<div class="ticket-qr"><img src="' + qrUrl(data) + '" alt="QR"></div>' +
    '<p class="ticket-detail"><strong>Code:</strong> ' + b.ticketCode + "</p>" +
    '<p class="ticket-detail"><strong>Passenger:</strong> ' + (b.passenger || "—") + " (Age " + (b.age || "—") + ")</p>" +
    '<p class="ticket-detail"><strong>ID:</strong> ' + (b.idNumber || "—") + "</p>" +
    '<p class="ticket-detail"><strong>Flight:</strong> ' + b.flightNo + " · Gate " + b.gate + "</p>" +
    '<p class="ticket-detail"><strong>Status:</strong> ' + b.status + "</p>" +
    '<p class="ticket-detail"><strong>Class / Seat:</strong> ' + b.flightClass + " " + b.seat + "</p>" +
    '<p class="ticket-detail"><strong>To:</strong> ' + b.office + "</p>" +
    '<p class="ticket-detail"><strong>Date:</strong> ' + b.date + " at " + b.time + "</p>" +
    (b.roundTrip ? '<p class="ticket-detail"><strong>Return:</strong> ' + (b.returnDate || "TBD") + "</p>" : "") +
    '<p class="ticket-detail"><strong>Bags:</strong> ' + (b.bags || 0) + "</p>" +
    '<p class="ticket-detail"><strong>Paid:</strong> $' + formatMoney(b.price) + "</p>";
  document.getElementById("ticket-modal").hidden = false;
}

document.getElementById("close-ticket").onclick = function () {
  document.getElementById("ticket-modal").hidden = true;
};
document.getElementById("print-ticket").onclick = function () {
  window.print();
};

function showBookings() {
  var filter = (document.getElementById("book-filter").value || "").toLowerCase();
  var list = getBookings().filter(function (b) {
    if (!filter) return true;
    return (b.office + " " + b.flightClass + " " + b.date + " " + (b.passenger || "")).toLowerCase().indexOf(filter) !== -1;
  });
  var box = document.getElementById("bookings");
  if (list.length === 0) {
    box.innerHTML = '<p class="empty">No bookings found.</p>';
    return;
  }
  box.innerHTML = list.map(function (b) {
    return '<div class="card">' +
      "<strong>" + b.flightClass + " · " + b.flightNo + " · Seat " + b.seat + " — $" + formatMoney(b.price) + "</strong>" +
      "<span>" + b.office + " · " + b.status + " · Gate " + b.gate + "</span>" +
      "<span>" + b.date + " at " + b.time + (b.roundTrip ? " · Round trip" : "") + "</span>" +
      "<span>Passenger: " + (b.passenger || "—") + "</span>" +
      '<button type="button" class="btn-ticket" onclick="viewTicket(' + b.id + ')">View / Print Ticket</button>' +
      '<button type="button" class="btn-cancel" onclick="cancelBooking(' + b.id + ')">Cancel</button>' +
      "</div>";
  }).join("");
}
document.getElementById("book-filter").oninput = showBookings;

function viewTicket(id) {
  var list = getBookings();
  for (var i = 0; i < list.length; i++) if (list[i].id === id) { showTicket(list[i]); return; }
}
function cancelBooking(id, email) {
  var list = getBookings(email);
  var booking = null;
  for (var i = 0; i < list.length; i++) if (list[i].id === id) booking = list[i];
  if (booking && booking.price) setBalance(getBalance(email) + booking.price, email);
  list = list.filter(function (b) { return b.id !== id; });
  saveBookings(list, email);
  var s = getSession();
  logActivity((s ? s.name : "User") + " cancelled a booking");
  if (!email) showBookings();
  updateDisplays();
  if (isAdmin() && document.getElementById("page-admin") && !document.getElementById("page-admin").hidden) showAdminPanel();
}

document.getElementById("topup-form").onsubmit = function (e) {
  e.preventDefault();
  var amount = Number(document.getElementById("topup-amount").value);
  var method = document.getElementById("pay-method").value;
  var msg = document.getElementById("topup-msg");
  if (!amount || amount < 1) { msg.style.color = "#e74c3c"; msg.textContent = "Enter a valid amount."; return; }
  if (!method) { msg.style.color = "#e74c3c"; msg.textContent = "Select a payment method."; return; }
  setBalance(getBalance() + amount);
  logActivity(getSession().name + " added $" + amount + " via " + method);
  msg.style.color = "";
  msg.textContent = "Success! $" + formatMoney(amount) + " added via " + method + ".";
  document.getElementById("topup-form").reset();
  setTimeout(function () { msg.textContent = ""; }, 3500);
};

document.getElementById("pass-form").onsubmit = function (e) {
  e.preventDefault();
  var oldP = document.getElementById("old-pass").value;
  var newP = document.getElementById("new-pass").value;
  var msg = document.getElementById("pass-msg");
  var s = getSession();
  var users = getUsers();
  var u = users.find(function (x) { return x.email.toLowerCase() === s.email.toLowerCase(); });
  if (!u || u.password !== oldP) { msg.style.color = "#e74c3c"; msg.textContent = "Current password is wrong."; return; }
  if (newP.length < 6) { msg.style.color = "#e74c3c"; msg.textContent = "New password must be 6+ characters."; return; }
  u.password = newP;
  saveUsers(users);
  logActivity(s.name + " changed password");
  msg.style.color = "";
  msg.textContent = "Password updated.";
  document.getElementById("pass-form").reset();
};

function showAdminPanel() {
  var users = getUsers();
  var collected = 0;
  users.forEach(function (u) {
    getBookings(u.email).forEach(function (b) { collected += Number(b.price || 0); });
  });
  document.getElementById("admin-collected").textContent = "$" + formatMoney(collected);
  var countEl = document.getElementById("admin-usercount");
  if (countEl) countEl.textContent = users.length;

  document.getElementById("admin-list").innerHTML = users.map(function (u) {
    var bal = getBalance(u.email);
    var flights = getTotalFlights(u.email);
    var pts = getPoints(u.email);
    var bookings = getBookings(u.email);
    var mem = getMembership(flights);
    var role = u.isAdmin || u.email.toLowerCase() === DEFAULT_USER.email.toLowerCase() ? "ADMIN" : "User";
    var frozen = u.frozen ? "FROZEN" : "Active";
    var safe = encodeURIComponent(u.email);
    var booksHtml = bookings.length === 0 ? "<p>No bookings.</p>" : bookings.map(function (b) {
      return "<p>• " + b.flightClass + " " + (b.flightNo || "") + " seat " + b.seat +
        " → " + b.office + " | $" + formatMoney(b.price) +
        ' <button type="button" class="btn-cancel" onclick="adminRefund(decodeURIComponent(\'' + safe + "')," + b.id + ')">Refund</button></p>';
    }).join("");
    return '<div class="admin-user-card">' +
      "<h3>" + (u.name || u.email) + " (" + role + " · " + frozen + ")</h3>" +
      '<p class="admin-meta">' + u.email + "</p>" +
      '<p class="admin-meta">Wallet $' + formatMoney(bal) + " · Flights " + flights +
      " · " + mem.name + " · Pts " + pts + "</p>" +
      (role === "ADMIN" ? "<p class=\"tiny-note\">Admin account cannot be deleted.</p>" :
        '<button type="button" class="btn-ticket" onclick="toggleFreeze(decodeURIComponent(\'' + safe + "'))\">" +
        (u.frozen ? "Unfreeze" : "Freeze") + " Account</button>" +
        '<button type="button" class="btn-delete" onclick="adminDeleteUser(decodeURIComponent(\'' + safe + "'))\">Delete Account</button>") +
      '<div class="admin-bookings">' + booksHtml + "</div></div>";
  }).join("");

  var log = JSON.parse(localStorage.getItem("vip_activity") || "[]");
  document.getElementById("admin-log").innerHTML = log.length
    ? log.map(function (x) { return "<p>" + x.t + " — " + x.text + "</p>"; }).join("")
    : "<p>No activity yet.</p>";
}

function wipeUserStorage(email) {
  var s = slug(email);
  var prefixes = ["vip_wallet_", "vip_bookings_", "vip_total_flights_", "vip_points_"];
  prefixes.forEach(function (pre) {
    localStorage.removeItem(pre + s);
  });
  // also remove any leftover keys for that user
  var toRemove = [];
  for (var i = 0; i < localStorage.length; i++) {
    var k = localStorage.key(i);
    if (k && k.indexOf("_" + s) !== -1 && k.indexOf("vip_") === 0) toRemove.push(k);
  }
  toRemove.forEach(function (k) { localStorage.removeItem(k); });
}

function adminDeleteUser(email) {
  if (email.toLowerCase() === DEFAULT_USER.email.toLowerCase()) {
    alert("Admin account cannot be deleted.");
    return;
  }
  if (!confirm("Permanently delete this account and ALL of their data?\n" + email)) return;
  wipeUserStorage(email);
  var users = getUsers().filter(function (u) {
    return u.email.toLowerCase() !== email.toLowerCase();
  });
  saveUsers(users);
  logActivity("Admin permanently deleted account: " + email);
  showAdminPanel();
}

function deleteAllUsers() {
  if (!confirm("Delete ALL user accounts and their data?\nAdmin login will stay.")) return;
  if (!confirm("This cannot be undone. Continue?")) return;
  var users = getUsers();
  users.forEach(function (u) {
    if (u.email.toLowerCase() !== DEFAULT_USER.email.toLowerCase()) {
      wipeUserStorage(u.email);
    }
  });
  saveUsers([DEFAULT_USER]);
  logActivity("Admin deleted ALL user accounts");
  showAdminPanel();
  alert("All user accounts were removed. Admin remains.");
}

function toggleFreeze(email) {
  var users = getUsers();
  users.forEach(function (u) {
    if (u.email.toLowerCase() === email.toLowerCase()) u.frozen = !u.frozen;
  });
  saveUsers(users);
  logActivity("Admin toggled freeze for " + email);
  showAdminPanel();
}
function adminRefund(email, id) {
  cancelBooking(id, email);
  logActivity("Admin refunded a booking for " + email);
  showAdminPanel();
}

document.getElementById("delete-all-users").onclick = deleteAllUsers;
document.getElementById("clear-log").onclick = function () {
  if (!confirm("Clear the activity log?")) return;
  localStorage.removeItem("vip_activity");
  showAdminPanel();
};
